var express = require("express");

var app = express();

console.log("running");
app.use(express.static("public"));

app.get("/", function(req, res){
	//res.render("home.ejs")
})

app.listen(process.env.port || "3000", 
		   process.env.ip, 
		   function(){
	console.log("Sever is listening")
	}
);